import tkinter as tk
from PIL import ImageTk, Image

class GroceryAppGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Grocery Application")

        # Load and resize the background image
        bg_image = Image.open("grocery_background.jpg")
        bg_image = bg_image.resize((900, 700), Image.ANTIALIAS)
        self.background = ImageTk.PhotoImage(bg_image)

        # Create a canvas to hold the background image
        self.canvas = tk.Canvas(root, width=900, height=700)
        self.canvas.pack()

        # Place the background image on the canvas
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.background)




class Product:
    def __init__(self, name, price, category):
        self.name = name
        self.price = price
        self.category = category

class ShoppingCart:
    def __init__(self):
        self.items = []

    def add_item(self, product, quantity):
        self.items.append((product, quantity))

    def remove_item(self, product_name):
        for item in self.items:
            if item[0].name == product_name:
                self.items.remove(item)
                return True
        return False

    def calculate_total(self):
        total = 0
        for item in self.items:
            total += item[0].price * item[1]
        return total

class GroceryAppGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Grocery Application")

        self.products = [
            Product("Apple", 2, "Fruit"),
            Product("Banana", 1, "Fruit"),
            Product("Orange", 3, "Fruit"),
            Product("Cherry", 2, "Fruit"),
            Product("Papaya", 1, "Fruit"),
            Product("Strawberry", 3, "Fruit"),
            Product("Pear", 2, "Fruit"),
            Product("Pineapple", 1, "Fruit"),
            Product("Grapes", 3, "Fruit"),
            Product("Watermelon", 2, "Fruit"),
            Product("Pomegranate", 1, "Fruit"),
            Product("Date", 3, "Fruit"),
            Product("Spinach", 2, "Vegetable"),
            Product("Tomato", 1, "Vegetable"),
            Product("Potato", 3, "Vegetable"),
            Product("Pumpkin", 2, "Vegetable"),
            Product("Bottle-gourd", 1, "Vegetable"),
            Product("Beans", 3, "Vegetable"),
            Product("Cabbage", 2, "Vegetable"),
            Product("Lady’s finger", 1, "Vegetable"),
            Product("Snake beans", 3, "Vegetable"),
            Product("Broad beans", 2, "Vegetable"),
            Product("Cauliflower", 1, "Vegetable"),
            Product("Brinjal", 3, "Vegetable"),
            Product("Carrot", 3, "Vegetable"),
        ]
        self.cart = ShoppingCart()

        self.fruit_label = tk.Label(root, text="Fruits", font=("Helvetica", 16, "bold"))
        self.fruit_label.pack(pady=5)

        self.fruit_listbox = tk.Listbox(root, width=50, bg="lightpink")
        self.fruit_listbox.pack(pady=5)

        self.vegetable_label = tk.Label(root, text="Vegetables", font=("Helvetica", 16, "bold"))
        self.vegetable_label.pack(pady=5)

        self.vegetable_listbox = tk.Listbox(root, width=50, bg="lightgreen")
        self.vegetable_listbox.pack(pady=5)

        for product in self.products:
            if product.category == "Fruit":
                self.fruit_listbox.insert(tk.END, f"{product.name} - ${product.price}")
            elif product.category == "Vegetable":
                self.vegetable_listbox.insert(tk.END, f"{product.name} - ${product.price}")

        self.add_to_cart_btn = tk.Button(root, text="Add to Cart", command=self.add_to_cart, bg="black", fg="white")
        self.add_to_cart_btn.pack(pady=5)

        self.remove_from_cart_entry = tk.Entry(root, width=30)
        self.remove_from_cart_entry.pack(pady=5)
        self.remove_from_cart_btn = tk.Button(root, text="Remove from Cart", command=self.remove_from_cart,  bg="black", fg="white")
        self.remove_from_cart_btn.pack(pady=5)

        self.display_cart_btn = tk.Button(root, text="Display Cart", command=self.display_cart,  bg="black", fg="white")
        self.display_cart_btn.pack(pady=5)

        self.total_label = tk.Label(root, text="")
        self.total_label.pack(pady=5)


    def add_to_cart(self):
        selected_fruit_index = self.fruit_listbox.curselection()
        selected_vegetable_index = self.vegetable_listbox.curselection()

        if selected_fruit_index:
            selected_product = self.products[selected_fruit_index[0]]
            self.cart.add_item(selected_product, 1)
            self.total_label.config(text=f"Total: ${self.cart.calculate_total()}")
        elif selected_vegetable_index:
            selected_product = self.products[selected_vegetable_index[0]]
            self.cart.add_item(selected_product, 1)
            self.total_label.config(text=f"Total: ${self.cart.calculate_total()}")

    def remove_from_cart(self):
        product_name = self.remove_from_cart_entry.get()
        if product_name:
            if self.cart.remove_item(product_name):
                self.total_label.config(text=f"Total: ${self.cart.calculate_total()}")
            else:
                self.total_label.config(text=f"{product_name} is not in the cart.")

    def display_cart(self):
        cart_window = tk.Toplevel(self.root,)
        cart_window.title("Shopping Cart")

        cart_listbox = tk.Listbox(cart_window, width=50)
        cart_listbox.pack(pady=10)

        for item in self.cart.items:
            cart_listbox.insert(tk.END, f"{item[1]} {item[0].name}(s) - ${item[0].price} each")

        total_label = tk.Label(cart_window, text=f"Total Bill: ${self.cart.calculate_total()}")
        total_label.pack(pady=5)


if __name__ == "__main__":
    root = tk.Tk()
    app = GroceryAppGUI(root)
    root.geometry("900x700+300+200",)
    root.resizable(False, False)
    root.mainloop()
